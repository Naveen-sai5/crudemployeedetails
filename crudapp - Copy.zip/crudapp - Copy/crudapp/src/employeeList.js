function EmployeeList({employees, deleteEmployee, editEmployee}) {
    return (
        <table className='table m-3 '>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Salary</th>
                    <th>Designation</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                {
                    employees.map((data) => (
                        <tr key={data.id} >
                            <td>{data.id}</td>
                            <td>{data.name}</td>
                            <td>{data.salary}</td>
                            <td>{data.designation}</td>
                            <td>
                                <button className='btn btn-primary m-1' onClick={() => editEmployee(data)}>Edit</button>
                                <button className="btn btn-danger m-1" onClick={() => deleteEmployee(data.id)}>Delete</button>
                            </td>
                        </tr>
                    ))
                }
            </tbody>
        </table>
    )



};

export default EmployeeList;
