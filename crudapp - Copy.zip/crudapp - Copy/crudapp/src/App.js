import React from "react";
import EmployeeList from "./employeeList";
import { deleteData, getData, putData, postData } from './Api';
import { useEffect, useState } from 'react';
import EmployeeForm from "./Form";
import 'bootstrap/dist/css/bootstrap.min.css'
import axios from 'axios'

// function App(){
//     useEffect(()=> {
//         axios.get('https://localhost:3001/getUsers')
//         .then(users => setUsers(users.data))
//         .catch(err => console.log(err))
//     })
// }


const App= () => {
    const [employee, setEmployees] = useState([]);
    const [edit, setEdit] = useState(false);
    const [openForm, setOpenForm] = useState(false);
    const [initialForm, setForm] = useState({ name: '', salary: '', designation: '' })
    useEffect(() => {
        getAllEmployees();
    }, [])

    async function getAllEmployees() {
        const response = await getData();
        setEmployees(response.data);
    }
    async function addEmployee(employee) {
        let data = {
            name: employee.name,
            salary: employee.salary,
            Designation: employee.designation,
        }
        if (edit)
            await putData(employee.id, data);
        else
            await postData(data);
        getAllEmployees();
        setOpenForm(false);


    }
    async function deleteEmployee(id) {
        await deleteData(id);
        getAllEmployees();
    }

    function editEmployee(value) {
        setEdit(true);
        setOpenForm(true);
        setForm(value)

    }
    function closeForm() {
        setOpenForm(false)
    }
    function showForm() {
        setForm({ name: '', salary: '', designation: '' })
        setOpenForm(true);
        setEdit(false);

    }

    return (

        <div className="wrapper m-5 w-50">
            <h2 className="text-primary text-center">Employee Details </h2>
            <button className="btn btn-primary float-end" onClick={() => { showForm() }}>Add new</button>
            <EmployeeList employees={employee} deleteEmployee={deleteEmployee} editEmployee={editEmployee}></EmployeeList>
            {openForm && <EmployeeForm addEmployee={addEmployee} data={initialForm} closeForm={closeForm}  ></EmployeeForm>}
        </div>

    )

};

export default App;
