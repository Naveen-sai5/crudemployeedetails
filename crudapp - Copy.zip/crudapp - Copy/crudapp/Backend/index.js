const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
// const UserModel = require(' ./models/Users')

const App = express()
App.use(cors())
App.use(express.json())

mongoose.connect("mongodb://127.0.0.1:27017/tutorial")
.then(()=>{
    console.log('mongodb connected');

})
.catch(()=>{
    console.log('error');
})

const tutSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    }

})
 const collection=new mongoose.model('tut',tutSchema)

 data=[{
    name:"james"
 },
 {
    name:"Ryan"
 },
 {
    name:"Maddy"
 }]
 
collection.insertMany(data)


// app.get('/getUsers', (req, res) => {
//     UserModel.find()
//     .then(users => res.json(users))
//     .catch(err => res.json(err))
// })

// app.listen(3001, () => {
//     console.log("server is running")
// })